class DefaultConstructor
{
	void display()
	{
		System.out.print("Name is Kripasindhu.");
	}
}
class Final
{
	public static void main(String arg[])
	{
		DefaultConstructor obj = new DefaultConstructor();
		obj.display();
	}
}