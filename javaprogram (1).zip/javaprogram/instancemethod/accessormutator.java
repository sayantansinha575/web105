import java.util.Scanner;
class Students
{
	private int roll;
	private String name;
	public int getRoll() // accessor method
	{
		return roll;
	}
	public void setRoll(int roll) // mutator method
	{
		this.roll = roll;
	}

	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public void display()
	{
		System.out.println("Roll is "+roll);
		System.out.println("Name is "+name);
	}
}
class Final
{
	public static void main(String arg[])
	{
		Students obj = new Students();
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter student roll number:");
		int r = sc.nextInt();
		System.out.println("Enter student name:");
		String s = sc.nextLine();

		obj.setRoll(r);
		obj.setName(s);
		obj.display();
	}
}