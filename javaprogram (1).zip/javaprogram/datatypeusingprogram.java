class B
{
	public static void main(String[] args) {
		int a = 30;
		String b = "Kripasindhu !";
		System.out.println("Integer value = "+a);
		System.out.print("String value = "+b);
		
	}
}