class Gtec
{
	void display()
	{
		System.out.println("1. Addittion");
		System.out.println("2. Division");
		System.out.println("3. Modulus");
	}
	void switchCase()
	{
		int choice = 3;
		switch(choice)
		{
			case 1:
			int a = 3;
			int b = 4;
			int c = a+b;
			System.out.println("Addition = "+c);
			break;
			case 2:
			int d = 6;
			int e = 2;
			int f = d/e;
			System.out.println("Division = "+f);
			break;
			case 3:
			int g = 3;
			int h = 4;
			int i = g%h;
			System.out.println("Modulus = "+i);
			break;
			default:
			System.out.println("Wrong Statement...");

		}
	}
}
class Final
{
	public static void main(String arg[])
	{
		Gtec obj = new Gtec();
		obj.display();
		obj.switchCase();

	}
}