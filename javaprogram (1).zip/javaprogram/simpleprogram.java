class A
{
	public static void main(String arg[])
	{
		System.out.println("Hi Kripasindhu !");
		System.out.print("Hi Sayantan");
	}
}