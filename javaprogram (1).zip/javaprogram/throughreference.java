class D{
	int d;
	String c;
}
class Refclass
{
	public static void main(String[] args) {

		D obj = new D();
		obj.d = 40;
		obj.c = "Management !";
		System.out.println("Integer value = "+obj.d);
		System.out.print("Integer value = "+obj.c);
	}
}