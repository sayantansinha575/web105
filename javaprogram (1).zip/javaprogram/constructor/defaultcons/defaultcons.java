class Gtec
{
	void Gtec()
	{
	System.out.print("Hi Sayantan are you ready?");
	}
}
class Final
{
	public static void main(String arg[])
	{
	Gtec obj = new Gtec();
	obj.Gtec();
	}
}