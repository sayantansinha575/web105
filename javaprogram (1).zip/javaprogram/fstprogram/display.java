class Gtech
{
	public static void main(String arg[])
	{
	System.out.print("Hi Depayan...");
	}
}