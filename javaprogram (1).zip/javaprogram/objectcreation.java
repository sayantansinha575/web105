class C
{
	int d = 30;
	String b = "Java";
}
class Final{
	public static void main(String[] args) {
		C obj = new C();
		System.out.println("Integer value = "+obj.d);
		System.out.print("String value = "+obj.b);
	}
}