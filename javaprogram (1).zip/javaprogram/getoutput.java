class E{
	public static void main(String[] args) {
		int a=0;
		String b="";
		System.out.println("Output of an Integer value = "+a);
		System.out.println("Output of a string value = "+b);	
	}
}