class Gtech
{
	void display()
	{
	System.out.print("Hi Depayan...");
	}
}
class MainFunction
{
	public static void main(String arg[])
	{
		Gtech obj = new Gtech();
		obj.display();
	}
}