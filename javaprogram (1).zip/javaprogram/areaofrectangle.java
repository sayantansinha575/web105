class Rect
{
	int a,b,area;
	void getData(int l, int w)
	{
		a = l;
		b = w;
		area = (l*w);
	}
	void display()
	{
		System.out.println("Area of Rectangle = "+area);
	}
}
class Rectangle
{
	public static void main(String[] args) {
		Rect obj = new Rect();
		obj.getData(20,30);
		obj.display();
	}
}