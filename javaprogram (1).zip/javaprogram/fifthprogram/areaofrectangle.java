class Gtech
{
	float length;
	float width;
	float area;
	void rectAngle(float len,float wid)
	{
		length = len;
		width = wid;
		area = length * width;
	}
	void display()
	{
		System.out.print("Area of Rectangle = "+area);
	}
}
class MainClass
{
	public static void main(String arg[])
	{
		Gtech obj = new Gtech();
		obj.rectAngle(20.30f,34.20f);
		obj.display();
	}
}