class Gtech
{
	int roll;
	String name;
	void insertRecord(int r,String n)
	{
	roll = r;
	name = n;
	}
	void display()
	{
	System.out.println("Your name is: "+name);
	System.out.print("Your roll is: "+roll);
	}
}
class MainClass
{
	public static void main(String arg[])
	{
		Gtech obj = new Gtech();
		obj.insertRecord(02,"Sayantan");
		obj.display();
	}
}