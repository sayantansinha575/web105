class Gtec
{
	void perfectorNotNumber()
	{
		int num = 5;
		int i=1;
		int sum = 0;
		while(i<num)
		{
			if(num % i ==0)
			{
				sum = sum + i;
			}
			i++;
		}
		if(sum == num)
		{
			System.out.println(" Perfect Number");
		}
		else
		{
			System.out.println(" Not Perfect Number");
		}

	}

}
class Final
{
	public static void main(String arg[])
	{
		Gtec obj = new Gtec();
		obj.perfectorNotNumber();
	}
}