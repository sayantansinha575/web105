class Gtec
{
	void lcmandGcd()
	{
		int n1,n2,number1,number2,temp,gcd,lcm;
		 n1 = 20;
		 n2 = 30;
		number1 = n1;
		number2 = n2;
		while(number2 !=0)
		{
		temp = number2;
		number2 = number1 % number2;
		number1 = temp;
		}
		gcd = number1;
		lcm = (n1 * n2) / gcd;
		System.out.println("GCD "+gcd);
		System.out.print("LCM "+lcm);
	}
}
class Final
{
	public static void main(String[] args) {
		Gtec obj = new Gtec();
		obj.lcmandGcd();
		
	}
}