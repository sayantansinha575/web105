class Gtech
{
	void checkevenodd()
	{
		int i;
		for(i=2;i<=10;i++)
		{
			if(i%2==0)
			{
				System.out.println(i+"= Even Number");
			}
			else
			{
				System.out.println(i+"= Odd Number");
			}
		}
	}
}
class Final
{
	public static void main(String arg[])
	{
		Gtech obj = new Gtech();
		obj.checkevenodd();
	}
}
