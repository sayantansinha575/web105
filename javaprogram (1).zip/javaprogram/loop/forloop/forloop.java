class Gtech
{
	int i;
	void checkLoop()
	{
		for(i=0;i<=10;i=i+2)
		{
			System.out.println(i);
		}
	}
}
class Final
{
	public static void main(String arg[])
	{
		Gtech obj = new Gtech();
		obj.checkLoop();
	}
}