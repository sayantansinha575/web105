class Gtech
{
	void checkAddition()
	{
		int i,sum=0;
		for(i=1;i<=10;i++)
		{
			sum = sum+i;
		}
		System.out.println("Addition of 10 numbers = "+sum);
	}
}
class Final
{
	public static void main(String[] args) {
		Gtech obj = new Gtech();
		obj.checkAddition();
		
	}
}