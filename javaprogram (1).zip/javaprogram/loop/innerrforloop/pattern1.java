class Gtech
{
	void pattern()
	{
		int i,j;
		// for(i=0;i<5;i++) // Outer loop row
		// {
		// 	for(j=0;j<=i;j++) // inner loop column
		// 	{
		// 		System.out.print("*");
		// 	}
		// 	System.out.print("\n");
		// }

		// for(i=0;i<5;i++) // Outer loop row
		//  {
		//  	for(j=0;j<5;j++) // inner loop column
		//  	{
		//  		System.out.print("*");
		//  	}
		//  	System.out.print("\n");
		//  }

		// for(i=0;i<5;i++) // Outer loop row
		//  {
		//  	for(j=0;j<i;j++) // inner loop column
		//  	{
		//  		System.out.print(i);
		//  	}
		//  	System.out.print("\n");
		//  }

		// for(i=0;i<5;i++) // Outer loop row
		//  {
		//  	for(j=0;j<i;j++) // inner loop column
		//  	{
		//  		System.out.print(j);
		//  	}
		//  	System.out.print("\n");
		//  }

		 // for(i=0;i<5;i++) // Outer loop row
		 // {
		 // 	for(j=i;j<=i;j++) // inner loop column
		 // 	{
		 // 		System.out.print(j);
		 // 	}
		 // 	System.out.print("\n");
		 // }

		for(i=1;i<=5;i++) // Outer loop row
		 {
		 	for(j=5;j>=i;j--) // inner loop column
		 	{
		 		System.out.print(j);
		 	}
		 	System.out.print("\n");
		 }

	}
}
class Final
{
	public static void main(String arg[])
	{
		Gtech obj = new Gtech();
		obj.pattern();
	}
}