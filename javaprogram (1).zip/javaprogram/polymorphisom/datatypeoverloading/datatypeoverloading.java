class Gtec
{
	static int add(int a, int b)
	{
		return a+b;
	}
	static double add(double a, double b)
	{
		return a+b;
	}
	// static float add( a, int b)  // int method already has defined, so you can't be declared next time.
	// {
	// 	return a+b;
	// }

	void data()
	{
		System.out.println("Hi Polymorphisom");
	}
}
class Final
{
	public static void main(String[] args) {
		Gtec obj = new Gtec();
		System.out.println(Gtec.add(10,20));
		System.out.println(Gtec.add(10.00,20.20));
		System.out.println(Gtec.add(10,20));
		//obj.data();
		//System.out.println(Gtec.data()); // it should return compile time error
		
	}
}