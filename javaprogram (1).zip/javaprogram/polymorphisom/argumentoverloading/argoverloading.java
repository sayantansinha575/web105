class Gtec
{
	static int add(int a, int b)
	{
		return a+b;
	}
	static int add(int a, int b, int c)
	{
		return a+b+c;
	}
	void data()
	{
		System.out.println("Hi Polymorphisom");
	}
}
class Final
{
	public static void main(String[] args) {
		Gtec obj = new Gtec();
		System.out.println(Gtec.add(10,20));
		System.out.println(Gtec.add(10,20,30));
		//obj.data();
		//System.out.println(Gtec.data()); // it should return compile time error
		
	}
}