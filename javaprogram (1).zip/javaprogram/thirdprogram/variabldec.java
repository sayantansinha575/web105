class Gtech
{
	void display()
	{
		int age = 20;
		float sal = 20000.320f;
		String name = "Hi Depayan";
		System.out.println("your name is: "+name);
		System.out.println("Your Age is: "+age);
		System.out.print("Your Sallary is: "+sal);
	}
}
class MainClass
{
	public static void main(String[] args) {
		Gtech obj = new Gtech();
		obj.display();
		
	}
}