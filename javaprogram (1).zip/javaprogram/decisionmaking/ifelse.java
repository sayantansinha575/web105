class Gtec
{
	// void decisionMaking()
	// {
	// int a = 9;
	// int b = 6;
	// int c = 12;
	// 	if(a>b && a>c)
	// 	{
	// 		System.out.println("A is greater from B and C "+ a);
	// 	}
	// 	else if(b>a && b>c)
	// 	{
	// 		System.out.println("B is greater from A and C "+ b);
	// 	}
	// 	else
	// 	{
	// 		System.out.println("C is greater from A and B "+ c);
	// 	}
	// }
		int a,b,c;
	void decisionMaking(int a, int b, int c)
	{
		this.a = a;
		this.b = b;
		this.c = c;
		if(this.a>this.b && this.a>this.c)
		{
			System.out.println("A is greater from B and C "+ this.a);
		}
		else if(this.b>this.a && this.b>this.c)
		{
			System.out.println("B is greater from A and C "+ this.b);
		}
		else
		{
			System.out.println("C is greater from A and B "+ this.c);
		}
	}

}
class Final
{
	public static void main(String arg[])
	{
		Gtec obj = new Gtec();
		obj.decisionMaking(5,6,2);
	}
}