class Gtech
{
	public static void main(String arg[])
	{
		int a=2,b=3,c=5,add;

		add = a*b*c;
		System.out.println("Addition= "+add);
		System.out.print("Your Addition Result has been stored in add variable.");
	}
}