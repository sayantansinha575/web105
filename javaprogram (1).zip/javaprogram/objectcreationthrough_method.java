class D{
	int roll; 
	String nam;
	void getData(int r, String n)
	{
		roll=r;
		nam = n;
	}
	void display()
	{
		System.out.println("Student Name is:"+nam);
		System.out.print("Student Roll = "+roll);
	}
}
class Final{
	public static void main(String[] args) {
		D obj = new D();
		obj.getData(20,"Kripasindhu");
		obj.display();
		
	}
}