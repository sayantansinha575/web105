class Animal
{
	void eat()
	{
		System.out.print("Eating...");
	}
}
class Dog extends Animal
{
	void bark()
	{
		System.out.print("Barking...");
	}
}
class BabyDog extends Dog
{
	void weep()
	{
		System.out.print("Weeping...");
	}
}
class Final
{
	public static void main(String arg[])
	{
		BabyDog obj = new BabyDog();
		obj.eat();
		obj.bark();
		obj.weep();
	}
}