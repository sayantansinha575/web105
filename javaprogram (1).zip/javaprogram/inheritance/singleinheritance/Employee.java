class Employee   // parent class or super class or base class
{
	float salary = 4000.0f;
}
class Programmer extends Employee // programmer class is your child / base class
{
	int bonus=3200;

}
class Final
{
	public static void main(String arg[])
	{
		Programmer obj = new Programmer();
		//Employee obj = new Employee(); // it should return compile time error
		System.out.print("Programmer salary are "+obj.salary+" "+"His Bonus Amount are "+obj.bonus);
	}
}