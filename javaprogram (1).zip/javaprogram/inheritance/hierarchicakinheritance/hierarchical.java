class Animal
{
	void eat()
	{
	System.out.print("eating...");
	}
}
class cat extends Animal  
{
	void meow()
	{
		System.out.println("Meowing...");
	}
}
class Dog extends Animal
{
	void bark()
	{
		System.out.print("Barking...");
	}
}
class Final
{
	public static void main(String arg[])
	{
		cat obj = new cat();
		obj.meow();
		obj.eat();
		//obj.bark(); // compilation error
	}
}