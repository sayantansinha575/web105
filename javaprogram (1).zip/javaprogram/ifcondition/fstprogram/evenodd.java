class Gtech
{
	int num;
	void check(int num)
	{
		this.num = num;
		if(this.num%2==0)
		{
			System.out.println("Even number");
		}
		else
		{
			System.out.println("Odd number");
		}
	}
}
class Final
{
	public static void main(String[] args) {
		Gtech obj = new Gtech();
		obj.check(5);
	}
}