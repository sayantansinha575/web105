class Gtech
{
	void data()
	{
		int num=85;
		if(num<=100 && num>=90)
		{
			System.out.println("Grade-O");
		}
		else if(num<=89 && num>=80)
		{
			System.out.println("Grade-E");
		}
		else if(num<=79 && num>=70)
		{
			System.out.println("Grade-A");
		}
		else if(num<=69 && num>=60)
		{
			System.out.println("Grade-B");
		}
		else if(num<=59 && num>=50)
		{
			System.out.println("Grade-C");
		}
		else if(num<=49 && num>=40)
		{
			System.out.println("Grade-D");
		}
		else
		{
			System.out.println("Fail");
		}
	}
}
class Final
{
	public static void main(String arg[])
	{
		Gtech obj = new Gtech();
		obj.data();
	}
}