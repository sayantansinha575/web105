class Bank
{
	String holdername;
	int accno;
	float amt;

	void info(String name,int acc,float amout)
	{
		holdername = name;
		accno = acc;
		amt = amout;
		// System.out.println("Account Holder is-"+holdername);
		// System.out.println("Account Number is-"+accno);
		// System.out.println("Balance is-"+amt);

	}
	void deposite(float amout)
	{
		amt = amt+amout;
		// System.out.println("Current Balance is-"+amt);
	}

	void withDraw(float amout)
	{
		if(amt<amout)
		{
			System.out.println("In-sufficient balance..");
		}
		else
		{
			amt = amt-amout;
		}
	}
	void display()
	{
		System.out.println("Bank Account is- SBI");
		System.out.println("Account Holder is-"+holdername);
		System.out.println("Account Number is-"+accno);
		System.out.println("Balance is-"+amt);

	}
	
}
class Finalbank
{
	public static void main(String[] args) {

		Bank obj = new Bank();
		obj.info("Kripasindhu",12345,20000);
		obj.deposite(2000);
		obj.withDraw(1000);
		obj.display();
	}
}