import java.util.Scanner;
class Year
{
	public void Year(int y)
	{
		int yer;
		yer = y;
		if(((yer%4==0)&&(yer%100 !=0))||(yer%400==0))
		{
			System.out.println("Leap Year");
		}
		else
		{
			System.out.println("Not Leap Year");
		}
	}
}
class Final
{
	public static void main(String arg[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter year");
		int ye = sc.nextInt();
		Year yea = new Year();
		yea.Year(ye);
	}

}